export interface Check{
    text: string;
    value: string;
}
