import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { confirmPasswordValidator } from './check.validators';

@Component({
  selector: 'app-pass',
  templateUrl: './pass.component.html',
  styleUrls: ['./pass.component.css']
})

export class PassComponent {
  passwordform: FormGroup = new FormGroup({
    password1: new FormControl<string>('', [Validators.required]),
    password2: new FormControl<string>('', [Validators.required]),
  },{
    validators: [confirmPasswordValidator]
  });
}


